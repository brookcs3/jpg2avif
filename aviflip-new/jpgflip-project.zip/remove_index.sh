#!/bin/bash
git rm index.html
git commit -m "Remove old index.html to prepare for proper application deployment"
git push origin main